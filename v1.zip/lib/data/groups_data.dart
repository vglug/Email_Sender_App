final List<Map<String, dynamic>> groupsData = [
  {
    'name': 'Team A',
    'emails': ['seenuthiruvpm@gmail.com']
  },
  {
    'name': 'Team B',
    'emails': ['seenuthiruvpm@gmail.com', 'team.b@example.com']
  },
  {
    'name': 'Management',
    'emails': ['seenuthiruvpm@gmail.com', 'management@example.com']
  },
]; 