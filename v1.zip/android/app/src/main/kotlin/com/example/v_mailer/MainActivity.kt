package com.example.v_mailer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
